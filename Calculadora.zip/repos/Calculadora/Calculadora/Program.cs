﻿using System.Globalization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Calculadora
{
     class Program {
        static void Main(string[] args)
        {
            Console.WriteLine("Qual operação deseja fazer?");
            Console.WriteLine("1- Adição");
            Console.WriteLine("2- Subtração");
            Console.WriteLine("3- Multiplicação");
            Console.WriteLine("4- Divisão \n");



            double operacao = double.Parse(Console.ReadLine());



            Console.Write("Digite o primeiro número: ");



            double num1 = double.Parse(Console.ReadLine());



            Console.Write("Digite o segundo número: ");



            double num2 = double.Parse(Console.ReadLine());



            double resultado = 0;



            switch (operacao)
            {
                case 1:
                    {
                        resultado = Adicao(num1, num2);
                        break;
                    }



                case 2:
                    {
                        resultado = Subtracao(num1, num2);
                        break;
                    }



                case 3:
                    {
                        resultado = Multiplicacao(num1, num2);
                        break;
                    }



                case 4:
                    {
                        resultado = Divisao(num1, num2);
                        break;
                    }



                default:
                    Console.WriteLine("Número inválido. Digite um numero de 1 a 4.");
                    break;
            }



            Console.WriteLine("O resultado da operação com os números {0} e {1} é: {2}", num1.ToString("F2", CultureInfo.InvariantCulture), num2.ToString("F2", CultureInfo.InvariantCulture), resultado.ToString("F2", CultureInfo.InvariantCulture));
            Console.ReadLine();
        }



        public static double Adicao(double numero1, double numero2)
        {
            double result = numero1 + numero2;
            return result;
        }



        public static double Subtracao(double numero1, double numero2)
        {
            double result = numero1 - numero2;
            return result;
        }



        public static double Multiplicacao(double numero1, double numero2)
        {
            double result = numero1 * numero2;
            return result;
        }



        public static double Divisao(double numero1, double numero2)
        {
            double result = numero1 / numero2;
            return result;
        }
    }
}